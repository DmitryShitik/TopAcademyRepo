package Interface;

public interface Espresso {

    void doEspresso();


}
