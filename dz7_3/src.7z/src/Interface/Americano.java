package Interface;

public interface Americano {
    void doAmericano();
}
