package Interface;

public interface Late {
    void doLate();

}
