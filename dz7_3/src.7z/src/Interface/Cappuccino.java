package Interface;

public interface Cappuccino {
    void doCappuccino();
}
